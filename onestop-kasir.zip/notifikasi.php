<?php
include "./include/koneksi.php";


$sql = "SELECT * FROM transaksi where Tgl_Ambil IS NULL";
$result = $conn->query($sql);

echo $result->num_rows;
/*
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        echo "id: " . $row["id"]. " - Notification: " . $row["description"];
    }
} else {
    echo "0 results";
}

$conn->close();
?>